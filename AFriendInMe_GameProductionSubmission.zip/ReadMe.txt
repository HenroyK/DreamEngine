Controls

A/D       -   Left/Right
Space     -   Jump
W/S       -   Forward/Back
Shift+A/D -   Dash
Esc/P     -   Pause